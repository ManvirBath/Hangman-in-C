#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "dictionary.h"
#include "difficulty.h"

/*
	Initialize a selection of words (dictionary) for the game to randomly choose from.
	The dictionary is loaded from a .txt file of words.
	There are 3 different .txt files, one for each difficulty.
*/
int initDictionaryFromFile(enum DifficultyLevel difficulty, char dictionary[MAX_NUM_WORDS][MAX_WORD_LENGTH], int* numWordsPtr) {
	FILE* wfPtr = NULL;
	switch (difficulty) {
	case EASY:
	{
		if ((wfPtr = fopen("easy.txt", "r")) == NULL) {
			puts("Could not open words.txt. It may not exist.");
			return -1;
		}
		break;
	}
	case MEDIUM:
	{
		if ((wfPtr = fopen("medium.txt", "r")) == NULL) {
			puts("Could not open words.txt. It may not exist.");
			return -1;
		}
		break;
	}
	case HARD:
	{
		if ((wfPtr = fopen("hard.txt", "r")) == NULL) {
			puts("Could not open words.txt. It may not exist.");
			return -1;
		}
		break;
	}
	}

	char wordFromTextFile[MAX_WORD_LENGTH];
	while (wfPtr != NULL && fscanf(wfPtr, "%s\n", wordFromTextFile) != EOF) {
		strcpy(dictionary[*(numWordsPtr)], wordFromTextFile);
		++*(numWordsPtr);
	}
	fclose(wfPtr);

	return 1;
}

/*
	Choose a random word from the dictionary
*/
void chooseRandomWord(char chosenWord[MAX_WORD_LENGTH], char dictionary[MAX_NUM_WORDS][MAX_WORD_LENGTH], int numWords) {
	srand(time(NULL));

	int randomWordIndex = rand() % numWords;
	strcpy(chosenWord, dictionary[randomWordIndex]);
}