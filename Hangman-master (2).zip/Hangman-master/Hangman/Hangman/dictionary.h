#ifndef DICTIONARY_H
#define DICTIONARY_H

#define MAX_NUM_WORDS 256
#define MAX_WORD_LENGTH 32

int initDictionaryFromFile(enum DifficultyLevel difficulty, char dictionary[MAX_NUM_WORDS][MAX_WORD_LENGTH], int* numWordsPtr);
void chooseRandomWord(char chosenWord[MAX_WORD_LENGTH], char dictionary[MAX_NUM_WORDS][MAX_WORD_LENGTH], int numWords);

#endif