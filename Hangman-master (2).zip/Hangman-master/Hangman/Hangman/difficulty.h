#ifndef DIFFICULTY_H
#define DIFFICULTY_H

enum DifficultyLevel { EASY = 1, MEDIUM = 2, HARD = 3 };

enum DifficultyLevel promptDifficulty();
int getGuessesAllowed(enum DifficultyLevel difficulty);

#endif