#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include "difficulty.h"
#include "dictionary.h"
#include "word.h"
#include "draw.h"

// TODO use return values of scanf to check input
// TODO maybe make everything _s ?

int main(void) {
	// Choose difficulty level
	enum DifficultyLevel chosenDifficulty; 
	while ((chosenDifficulty = promptDifficulty()) == -1);
	int guessesAllowed = getGuessesAllowed(chosenDifficulty);

	// Initialize words from corresponding difficulty level .txt file
	int numWords = 0;
	char words[MAX_NUM_WORDS][MAX_WORD_LENGTH];
	if (initDictionaryFromFile(chosenDifficulty, words, &numWords) == -1) return;

	// Choose a random word
	char chosenWord[MAX_WORD_LENGTH];
	chooseRandomWord(chosenWord, words, numWords);
	int lengthOfChosenWord = strlen(chosenWord);

	// Initialize game loop variables
	int numCorrectCharacters = 0;
	char progressString[MAX_WORD_LENGTH] = { 0 };

	int numGuessedChracters = 0;
	char guessedCharacters[MAX_WORD_LENGTH];

	int numIncorrectGuesses = 0;

	while (numIncorrectGuesses < guessesAllowed) {
		int guessesRemaining = guessesAllowed - numIncorrectGuesses;

		showHangman(chosenDifficulty, guessesRemaining);
		printWordProgress(progressString, lengthOfChosenWord);
		printAlreadyGuessedCharacters(guessedCharacters, numGuessedChracters);
		printf("Guesses remaining: %d\n", guessesRemaining);

		// Get user guess
		char guess;
		do {
			puts("Enter your guess: ");
		} while (scanf(" %c", &guess) != 1);

		// Check guess
		if (isCharGuessedAlready(guessedCharacters, guess)) {
			printf("%c was already guessed\n", guess);
			continue;
		}

		bool correctGuess = checkGuess(guess, chosenWord, progressString, lengthOfChosenWord, &numCorrectCharacters);

		if (!correctGuess) {
			puts("Incorrect guess.\n");
			++numIncorrectGuesses;
		} else if (correctGuess) {
			puts("Correct guess.\n");
		}
		guessedCharacters[numGuessedChracters] = guess;
		++numGuessedChracters;

		// Check win condition, show win screen
		if (numCorrectCharacters == lengthOfChosenWord) {
			printf("You win! The word was %s.\n", chosenWord);
			return;
		}
	}

	// Show loss screen
	showHangman(chosenDifficulty, 0);
	printf("You lost, the word was %s\n", chosenWord);

	return 0;
}