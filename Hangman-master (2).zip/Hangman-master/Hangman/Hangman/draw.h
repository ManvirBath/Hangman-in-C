#ifndef DRAW_H
#define DRAW_H

void showHangman(enum Difficulty difficulty, int guessesRemaining);
void showHangmanEasy(int guessesRemaining);
void showHangmanMedium(int guessesRemaining);
void showHangmanHard(int guessesRemaining);

#endif