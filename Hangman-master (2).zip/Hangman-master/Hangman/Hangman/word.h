#ifndef WORD_H
#define WORD_H
#include "dictionary.h"

void printWordProgress(char progressString[], int lengthOfChosenWord);
void printAlreadyGuessedCharacters(char guessedCharacters[], int numGuessedCharacters);
bool isCharGuessedAlready(char progressString[MAX_WORD_LENGTH], char guess);
bool checkGuess(char guess, char chosenWord[], char guessedCharacters[], int lengthOfChosenWord, int* numCorrectCharactersPtr);

#endif