#include <stdio.h>
#include "difficulty.h"

/*
	Prompt the user for their preferred difficulty level.
	Return this difficulty as enum.
*/
enum DifficultyLevel promptDifficulty() {
	puts("Choose your difficulty level");
	puts("1 - Easy (4 letter words)");
	puts("2 - Medium (8 letter words)");
	puts("3 - Hard (10 letter words)");

	char choice;
	if (scanf(" %c", &choice) != 1) {
		puts("Invalid option");
		return -1;
	}

	switch (choice) {
	case '1':
		puts("You chose easy difficulty.");
		return EASY;
		break;
	case '2':
		puts("You chose medium difficulty.");
		return MEDIUM;
		break;
	case '3':
		puts("You chose hard difficulty.");
		return HARD;
		break;
	default:
		puts("Invalid option.");
		return -1;
		break;
	}
}

/*
	Return the number of guesses that are allowed for the corresponding difficulty level enum.
*/
int getGuessesAllowed(enum DifficultyLevel difficulty) {
	switch (difficulty) {
	case EASY:
		return 5;
		break;
	case MEDIUM:
		return 7;
		break;
	case HARD:
		return 9;
		break;
	}
}