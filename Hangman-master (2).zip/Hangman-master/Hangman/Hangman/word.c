#include <stdbool.h>
#include <stdio.h>
#include "word.h"
#include "dictionary.h"

/*
	Print the current progress towards the word
*/
void printWordProgress(char progressString[], int lengthOfChosenWord) {
	for (int i = 0; i < lengthOfChosenWord; ++i) {
		if (progressString[i] == 0) {
			printf("_ ");
		}
		else {
			printf("%c ", progressString[i]);
		}
	}
	printf("\n");
}

/*
	Print all of the characters that the user already tried to guess
*/
void printAlreadyGuessedCharacters(char guessedCharacters[], int numGuessedCharacters) {
	printf("Already guessed list: ");
	for (int i = 0; i < numGuessedCharacters; ++i) {
		printf("%c, ", guessedCharacters[i]);
	}
	printf("\n");
}

/*
	Check if a character has already been guessed by the user
*/
bool isCharGuessedAlready(char guessedCharacters[MAX_WORD_LENGTH], char guess) {
	for (int i = 0; i < MAX_WORD_LENGTH; ++i) {
		if (guessedCharacters[i] == guess) {
			return true;
		}
	}
	return false;
}

/*
	Check if the guess is part of the word, if it is, update the users progress variables
*/
bool checkGuess(char guess, char chosenWord[], char progressString[], int lengthOfChosenWord, int* numCorrectCharactersPtr) {
	bool isCorrectGuess = false;
	for (int i = 0; i < lengthOfChosenWord; ++i) {
		if (chosenWord[i] == guess) {
			progressString[i] = guess;
			++*(numCorrectCharactersPtr);
			isCorrectGuess = true;
		}
	}
	return isCorrectGuess;
}